class clsCine{
    constructor(){
        
        this.salas=[];
        this.CreateSalas();
        this.DrawSalas();
    }
//////////////////////////////////////////////////////////
    CreateSalas(){
        for (var i=1; i<3; i++){
            var sala1= new clsSala(i++, 10);
            var sala2= new clsSala(i++, 15);
            var sala3= new clsSala(i++, 5);
            this.salas.push(sala1,sala2,sala3);
        }
    }
/////////////////////////////////////////////////////////
    DrawSalas(){
        for (var i=0; i<3; i++){
            var tS= this.salas[i];
            var tsala=tS.Draw();
        }
    }
////////////////////////////////////////////////////////

}
